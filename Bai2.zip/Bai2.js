//CÂU 1: Dùng vòng lặp for, tính tổng của dãy sau: S(n) = 1 + 2 + 3 + ... + n

// function sum(n) {
//     let a = 0;
//     for(let i = 1; i <= n; i++)
//     {
//       a = i + a;
//     }
//     return a;
//   }
//console.log(sum(5));

//CÂU 2: Dùng vòng lặp for, tính tổng của dãy sau: S(n) = 1 + 1/2 + 1/3 + 1/4 + ... + 1/n
// function sum(n) {
//     let a = 0;
//     for(let i = 1; i <= n; i++)
//     {
//       a = a + 1/i;
//     }
//     return a;
//   }
// console.log(sum(2));

//CÂU 3: Dùng vòng lặp for, tính tổng của dãy sau: S(n) = 1 + 4 + 9 + 16 + 25 +  ... + n^2
// function sum(n) {
//     let a = 0;
//     for(let i = 1; i <= n; i++)
//     {
//       a = a + i*i;
//     }
//     return a;
//   }
// console.log(sum(2))

//CÂU 4: Dùng vòng lặp for, tính tổng của dãy sau: S(n) = 1 + 8 + 27 + ... + n^3
// function sum(n) {
//     let a = 0;
//     for(let i = 1; i <= n; i++)
//     {
//       a = a + i*i*i;
//     }
//     return a;
//   }
// console.log(sum(2))

// CÂU 5:Dùng vòng lặp while, in ra tất cả số nguyên dương lẻ < 100
// var a = 0
// while (a < 100) {
//     if (a%2 !=0) {
//         console.log(a);
//     }
// a++;
// }

// CÂU 6: Dùng vòng lặp while, in ra tất cả số nguyên dương chẵn < 100
// var a = 0
// while (a < 100) {
//     if (a%2 ==0) {
//         console.log(a);
//     }
// a++;
// }

//CÂU 7: Dùng vòng lặp while, in ra tất cả số nguyên âm lẻ > -100
// var a = 0
// while (a > - 100) {
//     if (a%2 !=0) {
//         console.log(a);
//     }
// a--;
// }

//CÂU 8: Dùng vòng lặp while, in ra tất cả số nguyên âm chẵn > -100
// var a = 0
// while (a > -100) {
//     if (a%2 ==0) {
//         console.log(a);
//     }
// a--;
// }

//CÂU 9: Viết chương trình in ra hình chữ nhật có cạnh a, b
// function rectangle(a,b)
// {
//     let print = '*'
//     for (let i = 1 ; i < b ; i++) {
//        print = print + ' *'
//     }

//     for (let e = 0; e < a; e++) {
//         console.log(print);
//     }
// }
// rectangle(3,5)

// CÂU 10: Viết chương trình in ra tam giác cân có chiều cao = h.

// function pyramid(N) {
//   let result = "";
//   for (let i = 1; i <= N; i++) {
//     for (j = N; j > i; j--) {
//       result += " ";
//     }
//     for (j = 1; j <= i; j++) {
//       result += "*" + " ";
//     }
//     result += "\n";
//   }
//   return result;
// }
// console.log(pyramid(3));


// CÂU 11: Đếm số lượng các số dương trong mảng arr = [10, 11, 12, -10, -11, -12]
// function arr(mang){
//   let so_duong = 0;                          
//   for (let i = 0; i < mang.length; i++) {
//     if (mang[i] > 0) {  
//       so_duong++;  
//     }
//   } 
//   return so_duong;
// }
// console.log(arr([10, 11, 12, -10, -11, -12]));


// CÂU 12: Đếm số lượng các số âm trong mảng arr = [10, 11, 12, -10, -11, -12]
// function arr(mang){
//   let so_am = 0;                          
//   for (let i = 0; i < mang.length; i++) {
//     if (mang[i] < 0) {  
//       so_am++;  
//     }
//   } 
//   return so_am;
// }
// console.log(arr([10, 11, 12, -10, -11, -12]));


// CÂU 13: Đếm số lượng các số chẵn trong mảng arr = [10, 11, 12, 13, 14, 15]
// function arr(mang){
//   let so_chan = 0;                          
//   for (let i = 0; i < mang.length; i++) {
//     if (mang[i] %2  == 0) {  
//       so_chan++;  
//     }
//   } 
//   return so_chan;
// }
// console.log(arr([10, 11, 12, 13, 14, 15]));


// CÂU 14: Đếm số lượng các số lẻ trong mảng arr = [10, 11, 12, 13, 14, 15]
// function arr(mang){
//   let so_le = 0;                          
//   for (let i = 0; i < mang.length; i++) {
//     if (mang[i] %2  != 0) {  
//       so_le++;  
//     }
//   } 
//   return so_le;
// }
// console.log(arr([10, 11, 12, 13, 14, 15]));


//CÂU 15: Tìm số lớn nhất trong mảng arr = [10, 11, 12, 13, 14, 15]
// function arr(mang) {
//   let so_lon_nhat = 0;
//   for( let i = 0; i < mang.length ; i++){
//    if ( so_lon_nhat < mang[i]){
//     so_lon_nhat = mang[i];
//    }
//   }
//   return so_lon_nhat;
// }
// console.log(arr([10, 11, 12, 13, 14, 15]));


//CÂU 16: Tìm số bé nhất trong mảng arr = [10, 11, 12, 13, 14, 15]
// function arr(mang) {
//   let so_be_nhat = mang[0];
//   for (let i = 0; i < mang.length; i++) {
//   if (so_be_nhat > mang[i]) {
//       so_be_nhat = mang[i];
//     }
//   }
//   return so_be_nhat;
// }
// console.log(arr([10, 11, 12, 13, 14, 15]));


//CÂU 17: Tính tổng các số âm trong mảng arr = [10, 11, 12, -10, -11, -12]
// function arr(mang) {
//   let tong = 0;
//   for (let i = 0; i < mang.length; i++) {
//   if ( mang[i] < 0)  {
//       tong += mang[i];
//     }
//   }
//   return tong;
// }
// console.log(arr([10, 11, 12, -10, -11, -12]));


// CÂU 18: Tính tổng các số dương trong mảng arr = [10, 11, 12, -10, -11, -12]
// function arr(mang) {
//   let tong = 0;
//   for (let i = 0; i < mang.length; i++) {
//   if ( mang[i] > 0)  {
//       tong += mang[i];
//     }
//   }
//   return tong;
// }
// console.log(arr([10, 11, 12, -10, -11, -12]));


//CÂU 19: Tìm số chẵn đầu tiên trong mảng arr = [10, 11, 12, 13, 14, 15] và arr2 = [1, 3, 5, 7, 9]. Nếu không tìm được số chẵn nào thì in ra -1
// function arr(mang1, mang2) {
//   let so_chan = -1;
//   let mang = mang1.concat(mang2)
//   for (let i = 0; i < mang.length; i++) {
//   if ( mang[i]%2 ==0)  {
//       so_chan = mang[i];
//       break;
//     }
//   }
//   return so_chan;
// }
// console.log(arr([10, 11, 12, 13, 14, 15] , [1, 3, 5, 7, 9] ));


//CÂU 20: Tìm số chẵn cuoi cung trong mảng arr = [10, 11, 12, 13, 14, 15] và arr2 = [1, 3, 5, 7, 9]. Nếu không tìm được số chẵn nào thì in ra -1
function arr(mang1, mang2) {
  let so_chan = -1;
  let mang = mang1.concat(mang2)
  for (let i = 0; i < mang.length; i++) {
  if ( mang[i]%2 ==0)  {
      so_chan = mang[i];
    }
  }
  return so_chan;
}
console.log(arr([10, 11, 12, 13, 14, 15] , [1, 3, 5, 7, 9] ));